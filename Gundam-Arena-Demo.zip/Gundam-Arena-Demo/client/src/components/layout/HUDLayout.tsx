import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Crosshair, Shield, Activity, Radio, Cpu, Settings, LogOut } from "lucide-react";
import { HUDButton } from "@/components/ui/hud-button";

export default function HUDLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Activity, label: "Cockpit" },
    { href: "/hangar", icon: Shield, label: "Hangar" },
    { href: "/missions", icon: Crosshair, label: "Missions" },
    { href: "/systems", icon: Cpu, label: "Systems" },
  ];

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Top HUD Bar */}
      <header className="h-16 border-b border-primary/20 bg-background/80 backdrop-blur-md flex items-center justify-between px-6 z-50 sticky top-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 border border-primary flex items-center justify-center animate-pulse">
            <Radio className="w-5 h-5 text-primary" />
          </div>
          <h1 className="text-xl font-display text-primary tracking-widest text-glow">
            G-SYSTEM <span className="text-xs text-muted-foreground align-top">V.9.0.1</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-8 font-mono text-sm text-primary/80">
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-muted-foreground">UNIT STATUS</span>
            <span className="text-green-400">ONLINE</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-muted-foreground">REACTOR</span>
            <span className="text-secondary animate-pulse">98.4%</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-muted-foreground">TIME</span>
            <span>{new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </header>

      <div className="flex flex-1 relative">
        {/* Left Side Nav */}
        <nav className="w-20 border-r border-primary/20 bg-background/50 flex flex-col items-center py-8 gap-6 z-40 backdrop-blur-sm">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div
                className={cn(
                  "w-12 h-12 flex items-center justify-center border border-transparent hover:border-primary/50 cursor-pointer transition-all duration-300 clip-corner-tl group",
                  location === item.href ? "bg-primary/20 border-primary text-glow" : "text-muted-foreground hover:text-primary"
                )}
              >
                <item.icon className="w-6 h-6 group-hover:scale-110 transition-transform" />
              </div>
            </Link>
          ))}
          
          <div className="mt-auto">
             <div className="w-12 h-12 flex items-center justify-center border border-transparent hover:border-destructive/50 cursor-pointer transition-all duration-300 clip-corner-tl group text-muted-foreground hover:text-destructive">
                <LogOut className="w-6 h-6 group-hover:scale-110 transition-transform" />
              </div>
          </div>
        </nav>

        {/* Main Content Area */}
        <main className="flex-1 relative overflow-hidden">
          {/* Scanline Effect */}
          <div className="scanline" />
          
          {/* Content Wrapper */}
          <div className="relative z-10 w-full h-full overflow-y-auto">
             {children}
          </div>

          {/* Decorative Corner Elements */}
          <div className="absolute top-4 left-4 w-32 h-32 border-t border-l border-primary/20 pointer-events-none" />
          <div className="absolute bottom-4 right-4 w-32 h-32 border-b border-r border-primary/20 pointer-events-none" />
        </main>
      </div>
    </div>
  );
}
