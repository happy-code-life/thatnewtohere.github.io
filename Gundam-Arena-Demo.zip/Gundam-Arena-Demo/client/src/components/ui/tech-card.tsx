import * as React from "react"
import { cn } from "@/lib/utils"

const TechCard = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      "bg-card text-card-foreground tech-border p-6 backdrop-blur-sm bg-opacity-80",
      className
    )}
    {...props}
  />
))
TechCard.displayName = "TechCard"

const TechCardHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn("flex flex-col space-y-1.5 p-6 border-b border-border/50", className)}
    {...props}
  />
))
TechCardHeader.displayName = "TechCardHeader"

const TechCardTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h3
    ref={ref}
    className={cn(
      "text-2xl font-semibold leading-none tracking-tight font-display text-primary",
      className
    )}
    {...props}
  />
))
TechCardTitle.displayName = "TechCardTitle"

const TechCardContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />
))
TechCardContent.displayName = "TechCardContent"

export { TechCard, TechCardHeader, TechCardTitle, TechCardContent }
