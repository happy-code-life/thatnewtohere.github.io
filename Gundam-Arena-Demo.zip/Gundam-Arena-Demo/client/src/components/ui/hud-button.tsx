import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const hudButtonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 clip-corner-br uppercase tracking-wider font-display border border-primary/30 hover:border-primary hover:text-glow active:scale-95",
  {
    variants: {
      variant: {
        default: "bg-primary/10 text-primary hover:bg-primary/20",
        destructive:
          "bg-destructive/10 text-destructive hover:bg-destructive/20 border-destructive/30 hover:border-destructive hover:text-glow-orange",
        outline:
          "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary:
          "bg-secondary/10 text-secondary hover:bg-secondary/20 border-secondary/30 hover:border-secondary hover:text-glow-orange",
        ghost: "hover:bg-accent hover:text-accent-foreground border-transparent hover:border-accent/50",
        link: "text-primary underline-offset-4 hover:underline border-transparent",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3",
        lg: "h-14 px-8 text-lg",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface HUDButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof hudButtonVariants> {
  asChild?: boolean
}

const HUDButton = React.forwardRef<HTMLButtonElement, HUDButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(hudButtonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
HUDButton.displayName = "HUDButton"

export { HUDButton, hudButtonVariants }
