import { motion } from "framer-motion";
import HUDLayout from "@/components/layout/HUDLayout";
import { HUDButton } from "@/components/ui/hud-button";
import { TechCard } from "@/components/ui/tech-card";
import hangarImage from "@assets/generated_images/giant_mecha_robot_in_hangar.png";
import { Wrench, Database, Zap, ArrowRight, BarChart3 } from "lucide-react";

export default function Hangar() {
  return (
    <HUDLayout>
      <div className="relative min-h-[calc(100vh-4rem)] flex">
        
        {/* Background - Left aligned image */}
        <div className="absolute inset-0 z-0">
          <img 
            src={hangarImage} 
            alt="Hangar View" 
            className="w-full h-full object-cover opacity-40"
          />
           <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        </div>

        <div className="relative z-10 container mx-auto p-8 grid grid-cols-12 gap-8 items-center h-full">
          
          {/* Left Info Panel */}
          <div className="col-span-5 space-y-6">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
            >
              <h1 className="text-6xl font-display text-white mb-2 tracking-tighter">RX-78-2</h1>
              <h2 className="text-2xl text-primary font-mono mb-6">PROTOTYPE CLOSE-QUARTERS COMBAT MOBILE SUIT</h2>
              
              <div className="space-y-4">
                <TechCard className="bg-black/80 border-l-4 border-l-primary">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-muted-foreground font-mono">ARMOR CLASS</span>
                    <span className="text-white font-display">LUNA-TITANIUM</span>
                  </div>
                  <div className="w-full bg-slate-800 h-1">
                     <div className="w-[85%] h-full bg-primary" />
                  </div>
                </TechCard>
                
                 <TechCard className="bg-black/80 border-l-4 border-l-secondary">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-muted-foreground font-mono">OUTPUT</span>
                    <span className="text-white font-display">1380 kW</span>
                  </div>
                   <div className="w-full bg-slate-800 h-1">
                     <div className="w-[92%] h-full bg-secondary" />
                  </div>
                </TechCard>
              </div>

              <div className="flex gap-4 mt-8">
                <HUDButton>
                  <Wrench className="w-4 h-4 mr-2" /> CUSTOMIZE
                </HUDButton>
                <HUDButton variant="secondary">
                  <Database className="w-4 h-4 mr-2" /> DATA LOGS
                </HUDButton>
              </div>
            </motion.div>
          </div>

          {/* Right Stats Grid */}
          <div className="col-span-7 grid grid-cols-2 gap-4">
            {[
              { label: "MOBILITY", val: 80, color: "bg-blue-500" },
              { label: "RANGE", val: 65, color: "bg-green-500" },
              { label: "MELEE", val: 95, color: "bg-red-500" },
              { label: "SENSOR", val: 70, color: "bg-yellow-500" }
            ].map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-black/50 border border-border p-4 clip-corner-br hover:bg-white/5 transition-colors"
              >
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-mono text-muted-foreground">{stat.label}</span>
                  <BarChart3 className="w-4 h-4 text-primary" />
                </div>
                <div className="flex gap-1 h-12 items-end">
                   {Array.from({ length: 10 }).map((_, i) => (
                     <div 
                       key={i} 
                       className={`flex-1 ${i < (stat.val / 10) ? stat.color : "bg-slate-800"}`}
                     />
                   ))}
                </div>
                <div className="text-right mt-2 text-2xl font-display text-white">{stat.val}%</div>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </HUDLayout>
  );
}
