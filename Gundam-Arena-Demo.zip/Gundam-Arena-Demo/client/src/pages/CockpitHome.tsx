import { motion } from "framer-motion";
import HUDLayout from "@/components/layout/HUDLayout";
import { HUDButton } from "@/components/ui/hud-button";
import { TechCard } from "@/components/ui/tech-card";
import cockpitImage from "@assets/generated_images/sci-fi_mecha_cockpit_view_hud.png";
import { AlertTriangle, Target, Zap, ShieldAlert, Cpu } from "lucide-react";

export default function CockpitHome() {
  return (
    <HUDLayout>
      <div className="relative min-h-[calc(100vh-4rem)] p-8 flex flex-col justify-end">
        
        {/* Background Image Layer */}
        <div className="absolute inset-0 z-0">
          <img 
            src={cockpitImage} 
            alt="Cockpit View" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        </div>

        {/* HUD Elements Overlay */}
        <div className="relative z-10 grid grid-cols-12 gap-6 pb-12">
          
          {/* Left Panel: Systems */}
          <div className="col-span-3 space-y-4">
            <TechCard className="bg-black/60 border-l-4 border-l-primary p-4">
              <h3 className="text-primary font-display text-lg mb-4 flex items-center gap-2">
                <Cpu className="w-5 h-5" /> SYSTEMS CHECK
              </h3>
              <div className="space-y-3 font-mono text-sm">
                <div className="flex justify-between items-center text-green-400">
                  <span>PROPULSION</span>
                  <span>100%</span>
                </div>
                <div className="w-full bg-slate-800 h-1">
                  <motion.div 
                    initial={{ width: 0 }} animate={{ width: "100%" }} 
                    className="h-full bg-green-400" 
                  />
                </div>

                <div className="flex justify-between items-center text-green-400">
                  <span>WEAPONS</span>
                  <span>READY</span>
                </div>
                <div className="w-full bg-slate-800 h-1">
                  <motion.div 
                    initial={{ width: 0 }} animate={{ width: "100%" }} 
                    className="h-full bg-green-400" 
                  />
                </div>

                <div className="flex justify-between items-center text-secondary">
                  <span>SHIELDING</span>
                  <span>85%</span>
                </div>
                <div className="w-full bg-slate-800 h-1">
                  <motion.div 
                    initial={{ width: 0 }} animate={{ width: "85%" }} 
                    className="h-full bg-secondary" 
                  />
                </div>
              </div>
            </TechCard>
          </div>

          {/* Center Panel: Aim/Notifications */}
          <div className="col-span-6 flex flex-col items-center justify-center pt-20">
             <motion.div 
               initial={{ scale: 0.8, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               transition={{ duration: 0.5 }}
               className="border border-primary/30 rounded-full w-96 h-96 flex items-center justify-center relative"
             >
                <div className="absolute inset-0 border-t border-b border-primary/50 w-full h-full rounded-full animate-spin-slow" />
                <Target className="w-16 h-16 text-primary/50" />
                <div className="absolute bottom-10 text-center">
                  <div className="text-destructive font-display tracking-widest text-lg animate-pulse">NO TARGET</div>
                </div>
             </motion.div>

             <div className="mt-12 flex gap-4">
               <HUDButton size="lg" className="w-48">ENGAGE</HUDButton>
               <HUDButton size="lg" variant="destructive" className="w-48">EMERGENCY</HUDButton>
             </div>
          </div>

          {/* Right Panel: Alerts */}
          <div className="col-span-3 space-y-4">
            <TechCard className="bg-black/60 border-r-4 border-r-destructive p-4">
              <h3 className="text-destructive font-display text-lg mb-4 flex items-center gap-2 justify-end">
                ALERTS <AlertTriangle className="w-5 h-5" />
              </h3>
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <motion.div 
                    key={i}
                    initial={{ x: 20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: i * 0.2 }}
                    className="bg-destructive/10 border border-destructive/20 p-2 text-xs font-mono text-destructive flex justify-between items-center"
                  >
                    <span>SECTOR 7 SIGNAL LOST</span>
                    <Zap className="w-3 h-3" />
                  </motion.div>
                ))}
              </div>
            </TechCard>
             <TechCard className="bg-black/60 border-r-4 border-r-primary p-4">
              <h3 className="text-primary font-display text-lg mb-4 flex items-center gap-2 justify-end">
                RADAR <ShieldAlert className="w-5 h-5" />
              </h3>
              <div className="aspect-square bg-slate-900 rounded-full border border-primary/20 relative overflow-hidden">
                 <div className="absolute top-1/2 left-1/2 w-full h-0.5 bg-green-500/20 -translate-x-1/2 -translate-y-1/2 rotate-45" />
                 <div className="absolute top-1/2 left-1/2 w-full h-0.5 bg-green-500/20 -translate-x-1/2 -translate-y-1/2 -rotate-45" />
                 <motion.div 
                   className="absolute top-1/2 left-1/2 w-1/2 h-0.5 bg-gradient-to-r from-green-500 to-transparent origin-left"
                   animate={{ rotate: 360 }}
                   transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                 />
                 <div className="absolute top-1/3 left-1/3 w-2 h-2 bg-red-500 rounded-full animate-ping" />
              </div>
            </TechCard>
          </div>

        </div>
      </div>
    </HUDLayout>
  );
}
