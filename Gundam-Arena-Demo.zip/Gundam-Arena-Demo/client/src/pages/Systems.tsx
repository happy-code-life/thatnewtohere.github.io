import HUDLayout from "@/components/layout/HUDLayout";
import { TechCard } from "@/components/ui/tech-card";
import { Cpu, Activity, Battery, Wifi } from "lucide-react";

export default function Systems() {
  return (
    <HUDLayout>
      <div className="p-8 max-w-4xl mx-auto space-y-6">
        <h1 className="text-4xl font-display text-primary mb-8 text-glow">SYSTEM DIAGNOSTICS</h1>
        
        <div className="grid grid-cols-2 gap-6">
          <TechCard className="border-l-4 border-l-green-500">
            <h3 className="text-xl font-display text-white mb-4 flex items-center gap-2">
              <Cpu className="text-green-500" /> CORE PROCESSOR
            </h3>
            <div className="space-y-2 font-mono text-green-400">
              <div className="flex justify-between"><span>TEMP</span><span>42°C</span></div>
              <div className="flex justify-between"><span>LOAD</span><span>12%</span></div>
              <div className="flex justify-between"><span>STATUS</span><span>OPTIMAL</span></div>
            </div>
          </TechCard>

          <TechCard className="border-l-4 border-l-secondary">
            <h3 className="text-xl font-display text-white mb-4 flex items-center gap-2">
              <Battery className="text-secondary" /> POWER CELL
            </h3>
            <div className="space-y-2 font-mono text-secondary">
              <div className="flex justify-between"><span>OUTPUT</span><span>98.4%</span></div>
              <div className="flex justify-between"><span>RECHARGE</span><span>ACTIVE</span></div>
              <div className="flex justify-between"><span>EST. TIME</span><span>42h</span></div>
            </div>
          </TechCard>
          
           <TechCard className="border-l-4 border-l-primary">
            <h3 className="text-xl font-display text-white mb-4 flex items-center gap-2">
              <Wifi className="text-primary" /> COMMS ARRAY
            </h3>
             <div className="space-y-2 font-mono text-primary">
              <div className="flex justify-between"><span>UPLINK</span><span>CONNECTED</span></div>
              <div className="flex justify-between"><span>LATENCY</span><span>12ms</span></div>
              <div className="flex justify-between"><span>ENCRYPTION</span><span>AES-4096</span></div>
            </div>
          </TechCard>

           <TechCard className="border-l-4 border-l-destructive">
            <h3 className="text-xl font-display text-white mb-4 flex items-center gap-2">
              <Activity className="text-destructive" /> WEAPON CONTROL
            </h3>
             <div className="space-y-2 font-mono text-destructive">
              <div className="flex justify-between"><span>BEAM RIFLE</span><span>STANDBY</span></div>
              <div className="flex justify-between"><span>VULCANS</span><span>LOADED</span></div>
              <div className="flex justify-between"><span>SABERS</span><span>CHARGED</span></div>
            </div>
          </TechCard>
        </div>
      </div>
    </HUDLayout>
  );
}
