import { motion } from "framer-motion";
import HUDLayout from "@/components/layout/HUDLayout";
import { HUDButton } from "@/components/ui/hud-button";
import { TechCard } from "@/components/ui/tech-card";
import mapImage from "@assets/generated_images/holographic_tactical_map.png";
import { MapPin, Skull, Trophy, Play } from "lucide-react";

export default function Missions() {
  const missions = [
    { id: 1, name: "OPERATION: STARFALL", difficulty: "HARD", location: "Sector 7 (Debris Field)", reward: "5000 GP" },
    { id: 2, name: "LUNAR PATROL", difficulty: "EASY", location: "Moon Surface", reward: "1200 GP" },
    { id: 3, name: "ATMOSPHERIC ENTRY", difficulty: "EXTREME", location: "Earth Orbit", reward: "8000 GP" },
  ];

  return (
    <HUDLayout>
      <div className="relative min-h-[calc(100vh-4rem)] p-8">
         {/* Background Map */}
        <div className="absolute inset-0 z-0 opacity-20">
          <img 
            src={mapImage} 
            alt="Map" 
            className="w-full h-full object-cover grayscale brightness-50"
          />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 border-b border-primary/30 pb-4"
          >
            <h1 className="text-4xl font-display text-primary text-glow">ACTIVE MISSIONS</h1>
            <p className="font-mono text-muted-foreground">SELECT DEPLOYMENT ZONE</p>
          </motion.div>

          <div className="grid gap-6">
            {missions.map((mission, idx) => (
              <motion.div
                key={mission.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: idx * 0.15 }}
              >
                <TechCard className="group hover:bg-primary/5 transition-all cursor-pointer border-l-4 border-l-transparent hover:border-l-primary">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-6 items-center">
                      <div className="w-16 h-16 bg-black/50 border border-primary/30 flex items-center justify-center text-primary font-display text-2xl group-hover:bg-primary group-hover:text-black transition-colors">
                        0{mission.id}
                      </div>
                      <div>
                        <h3 className="text-2xl font-display text-white group-hover:text-primary transition-colors">{mission.name}</h3>
                        <div className="flex gap-4 text-sm font-mono text-muted-foreground mt-1">
                          <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {mission.location}</span>
                          <span className={`flex items-center gap-1 ${mission.difficulty === 'EXTREME' ? 'text-destructive' : mission.difficulty === 'HARD' ? 'text-secondary' : 'text-green-400'}`}>
                             <Skull className="w-3 h-3" /> {mission.difficulty}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right">
                         <div className="text-xs text-muted-foreground font-mono mb-1">REWARD</div>
                         <div className="text-xl font-display text-yellow-400 flex items-center justify-end gap-2">
                           <Trophy className="w-4 h-4" /> {mission.reward}
                         </div>
                      </div>
                      <HUDButton className="opacity-0 group-hover:opacity-100 transition-opacity">
                         DEPLOY <Play className="w-4 h-4 ml-2" />
                      </HUDButton>
                    </div>
                  </div>
                </TechCard>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-12 p-6 border border-dashed border-primary/30 bg-black/40 text-center font-mono text-sm text-primary/50"
          >
             // END OF TRANSMISSION //
          </motion.div>
        </div>
      </div>
    </HUDLayout>
  );
}
